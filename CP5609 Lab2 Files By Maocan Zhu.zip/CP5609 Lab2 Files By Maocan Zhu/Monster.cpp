//
// Created by Nick Fan on 26/08/2022.
//

#include "Monster.h"

void Monster::touch() {
    set_color(ObjectColours);
}