//
// Created by Nick Fan on 26/08/2022.
//

#include "BoardObjectH.h"
#include "WallH.h"

void Wall :: touch ()
{
    set_color(color1);
}