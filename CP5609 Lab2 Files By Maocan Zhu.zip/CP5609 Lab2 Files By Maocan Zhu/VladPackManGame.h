//
// Created by Nick Fan on 26/08/2022.
//

#ifndef CP5609_LAB2_VLADPACKMANGAME_H
#define CP5609_LAB2_VLADPACKMANGAME_H


class VladPackManGame {

};


#endif //CP5609_LAB2_VLADPACKMANGAME_H
