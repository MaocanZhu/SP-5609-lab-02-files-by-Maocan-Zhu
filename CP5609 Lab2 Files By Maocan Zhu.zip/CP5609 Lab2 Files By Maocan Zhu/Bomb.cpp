//
// Created by Nick Fan on 26/08/2022.
//


#include "Bomb.h"

void Bomb::touch() {
    set_color(ObjectColours);
}